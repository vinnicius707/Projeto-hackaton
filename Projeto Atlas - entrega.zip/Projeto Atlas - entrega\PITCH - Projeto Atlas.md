# Projeto Atlas — roteiro do pitch (hackathon iPORT 2026)

> **Atlas**: o titã que carrega o mundo nas costas. A solução mostra quem está
> carregando peso demais **antes** que a pessoa ceda.

## 1. O problema (30 s)

O Azure DevOps responde bem **o quê** (work items), **onde** (projetos e sprints) e
**quando** (prazos). Mas o gestor ainda não sabe responder:

> **Qual é a disponibilidade da minha equipe agora? E quando ela já está no limite?**

Hoje ele descobre a sobrecarga quando a entrega atrasa — tarde demais.

## 2. A solução (30 s)

```
[ Azure DevOps ] → [ Atlas: capacidade + IA ] → [ decisão antes do problema ]
```

O Atlas **não substitui o Azure DevOps**: usa os dados dele (projetos, sprints,
work items, capacidade) e cruza com ausências e feriados para mostrar carga,
conflitos e oportunidades de realocação.

## 3. Demo (4 min) — com os dados que estão no sistema

Entre com o login admin (`111.111.111-11`).

| # | Tela | O que mostrar | Fala |
|---|---|---|---|
| 1 | **Utilização** | O heatmap, ordenado por "maior carga primeiro". Eduarda e Henrique em vermelho (~125%) há semanas; Carla com folga (59%). | "Em 5 segundos o gestor vê quem está no limite e quem tem folga — semana a semana." |
| 2 | **Alertas** | Gravidade alta no topo: sobrecarga e conflito da Eduarda e do Henrique; Ana de férias de 13 a 24/10 com itens em aberto (9 dias em conflito); Bruno em dois projetos ao mesmo tempo. | "O sistema não espera o gestor procurar: ele avisa — sobrecarga, férias com trabalho pendente, feriado no meio da sprint, sobreposição de projetos." |
| 3 | **Previsão** | Escolher o cenário **contratacao-2027** (simulação). "Próximo a piorar: 12/10, Ana Souza". No cartão dela: hoje Em risco → Conflito a partir de 12/10 → **pico de 135% na volta das férias (26/10)**, 10 h acumuladas, normaliza só em 12/11. Eduarda e Henrique: tendência de alta, até ~160% em novembro. | "O Atlas não mostra só o agora: ele prevê. O que não cabe hoje — férias com item em aberto, gente acima de 120% — escorrega para os dias seguintes. A Ana vai voltar das férias soterrada." |
| 4 | Sugestão → **Simular no Planejamento** | A sugestão já vem pronta: passar "Exportação do painel em PDF" para **Carla (59% na sprint)**. O botão abre a janela de simulação no Planejamento: Ana **119% → 99%**, Carla **59% → 71%**, com os avisos de ausência e do feriado de 12/10. | "Antes de mover, o gestor vê o impacto. Nada muda até ele confirmar — e o que ele confirma vai para um cenário de simulação, nunca para o estado real." |
| 5 | Confirmar e voltar à **Previsão** | Gravar no cenário. Na Previsão do mesmo cenário, a Ana cai de **135% para 126%** e de 10 h para 6,5 h acumuladas, e o Atlas já sugere o próximo item. Depois, **Desfazer** no cartão do Planejamento. | "Cenários permitem testar realocações, contratações, o próximo trimestre — sem mexer no que veio do Azure DevOps." |
| 6 | **IPORT AI** | Perguntar: *"Quem vai ficar sobrecarregado nas próximas semanas e o que eu faço antes?"* e *"Quem tem folga na próxima semana para pegar uma tarefa?"* | "O gestor pergunta em português e recebe a resposta com nomes, quando, por quê e o que mover. E cada pessoa só vê o que o cargo dela permite." |

> Dica: antes da demo, deixe o n8n no ar e mande uma pergunta qualquer ao IPORT AI
> (a primeira chamada depois de reiniciar o n8n é a mais lenta).

## 4. Os 6 requisitos do desafio (30 s)

| Requisito | Onde está |
|---|---|
| 1. Sincronizar projetos, work items, iterações, capacidade | Modelo de dados no Supabase com origem ADO e histórico de sincronização (o conector automático é o próximo passo) |
| 2. Capacidade semanal, ausências, calendário | Carga diária por pessoa, já descontando férias, consultas e eventos de equipe; feriados por calendário (BR, SP, Santos) |
| 3. Timeline por pessoa, atividade e período | **Planejamento**: pessoa × sprint, com os itens e as ausências |
| 4. Realocar com drag-and-drop | Arrastar (ou "Mover") → simulação → confirmar no cenário |
| 5. Heatmap de utilização e sobrecarga | **Utilização**: pessoa × semana, 6 faixas |
| 6. Alertar conflitos, ausências, feriados, sobreposição | **Alertas**: calculados na hora a partir do plano de cada cenário |

## 5. Diferenciais

- **Previsão de sobrecarga**: quem vai estourar nas próximas 8 semanas, quando, por quê (férias, plano acima de 100%, acúmulo, feriado) e quando normaliza.
- **Simular antes de mover**: antes e depois da carga de quem perde e de quem ganha o item — a um clique a partir da Previsão.
- **Sugestão de realocação**: qual item passar para quem (de preferência da mesma equipe, com a menor carga na sprint).
- **Cenários**: o estado real fica intocado; o gestor testa quantos planos quiser.
- **Perguntas em linguagem natural** (IPORT AI), respeitando o cargo de quem pergunta.
- **Segurança de verdade**: senhas em bcrypt, sessão com token, permissão decidida no servidor, IA sem acesso além do cargo.

## 6. Como funciona por dentro (se perguntarem)

- **Front-end**: React + TypeScript (Vite).
- **Backend**: n8n (APIs de login, capacidade e o agente de IA) + Supabase (Postgres).
- **IA**: agente no n8n com Gemini (e um modelo reserva), que consulta as mesmas APIs com o token do usuário.
- **Cálculo**: funções SQL; a carga de um cenário é a do estado real mais o efeito dos itens movidos, espalhado pelos dias úteis da sprint.
- **Previsão**: simulação dia a dia — cada pessoa aguenta até 120% das horas do dia; o que passa disso (ou cai num dia de ausência) vai para os dias seguintes. Simples de explicar e de auditar.

## 7. Próximos passos (fechamento, 20 s)

1. **Conector automático com o Azure DevOps** (work items, iterações, capacidade e days off), agendado no n8n.
2. **Previsão que aprende**: corrigir a estimativa pelo histórico de cada pessoa ("costuma subestimar 30%"), comparando o planejado com o realizado.
3. **Alerta de conhecimento concentrado**: quando só uma pessoa mexe num módulo (ex.: iCOMPLIANCE).

> *"Pensem grande. Simplifiquem. Criem algo que alguém realmente usaria."*
> O Atlas responde uma pergunta só — **quem está carregando peso demais?** — e ajuda a resolver antes do problema.
