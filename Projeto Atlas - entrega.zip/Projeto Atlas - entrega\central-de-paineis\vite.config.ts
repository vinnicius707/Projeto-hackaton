import react from "@vitejs/plugin-react";
import { readFileSync, rmSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { defineConfig, type Plugin } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

const PROJETO = __dirname;

const AVISO = "<!-- gerado pelo npm run build, não edite aqui. o código fica em src/ -->";

// tira o html do dist/ e põe na raiz, assim abre com duplo clique sem servidor
function moverParaRaiz(): Plugin {
  return {
    name: "mover-para-raiz",
    apply: "build",
    closeBundle() {
      const dist = resolve(PROJETO, "dist");
      const html = readFileSync(resolve(dist, "index.html"), "utf-8").replace(/^<!doctype html>/i, `<!doctype html>\n${AVISO}`);
      writeFileSync(resolve(PROJETO, "index.html"), html);
      // no windows o antivírus às vezes segura a pasta um pouco, por isso as tentativas
      rmSync(dist, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
      console.log("\n  Pronto! Abra o index.html com duplo clique.\n");
    },
  };
}

export default defineConfig({
  root: "src",
  envDir: PROJETO, // o .env.local fica na raiz, não dentro do src

  plugins: [react(), viteSingleFile(), moverParaRaiz()],

  server: {
    port: 5173,
    open: true,
  },

  build: {
    outDir: "../dist",
    emptyOutDir: true,
    sourcemap: false,
  },
});
